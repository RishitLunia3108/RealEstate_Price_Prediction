"""
Phase 2: RealEstateSense - LLM-Driven Insight Generation Engine
NLP and LangGraph-based Real Estate Advisory System
"""

__version__ = "2.0.0"
